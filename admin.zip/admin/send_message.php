<?php
$mobn=$_POST['mobn'];
$message=$_POST['message'];
echo 1;
?>
<?php
$connection = mysqli_connect("localhost", "decision_mentor","mentor@2019","decision_mentor_db");
?>